def helloworld(out):
    out.write("Hello World\n")
